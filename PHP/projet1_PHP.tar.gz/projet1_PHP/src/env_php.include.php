<?php
const title = "PHP started";
$lang = "fr";
$version = phpversion();
$date = date('d-m-Y-H:i');
$price = 100;
$off = false;
$version_plus = 7.5;
$prop_navigator = $_SERVER['HTTP_USER_AGENT'];
$addr_ip = $_SERVER['SERVER_ADDR'];
$admin = $_SERVER['SERVER_ADMIN'];
$signature = $_SERVER['SERVER_SIGNATURE'];
$main_css = './css/style.css';
