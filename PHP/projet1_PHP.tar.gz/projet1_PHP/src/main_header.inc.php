
<!DOCTYPE html>
<html lang="<?php print $lang ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php print title ?></title>
    <link rel="stylesheet" href="<?php print $main_css?>">
    <link rel="icon" href="https://pngimg.com/uploads/php/php_PNG18.png" type="image/png">
</head>