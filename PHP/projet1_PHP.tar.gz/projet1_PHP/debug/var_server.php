<pre>
    <?php
    print_r($_SERVER);
    ?>
</pre>